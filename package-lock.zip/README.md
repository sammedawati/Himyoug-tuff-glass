# Glass Tuffan Company Website

A commercial, dynamic website for an industrial glass manufacturing company, built with React and Tailwind CSS.

## Features

- **Modern UI/UX**: Professional Blue & White corporate theme with animations (Framer Motion, AOS).
- **Responsive Design**: Fully mobile-compatible.
- **Dynamic Content**: Structured for Firebase Firestore integration.
- **Admin Panel**: Secure dashboard for managing inquiries and products.
- **Contact & Quote Forms**: Integrated with Firebase.

## Setup Instructions

1.  **Install Dependencies**:
    ```bash
    npm install
    ```

2.  **Configure Firebase**:
    -   Create a project at [Firebase Console](https://console.firebase.google.com/).
    -   Enable **Authentication** (Email/Password).
    -   Enable **Firestore Database**.
    -   Enable **Storage**.
    -   Copy your Firebase Config keys.
    -   Create a `.env` file in the root directory (based on `.env.example` if provided, or just edit `src/services/firebase.js` directly with your keys).

3.  **Run Locally**:
    ```bash
    npm start
    ```
    The app will open at `http://localhost:3000`.

## Admin Access
-   Navigate to `/admin/login`.
-   **Demo Credentials**: `admin@demo.com` / `admin123`.
-   To use real auth, sign up a user in Firebase and remove the mock bypass in `src/pages/admin/AdminLogin.jsx`.

## Tech Stack
-   **React** (Create React App structure)
-   **Tailwind CSS** (CDN for styling flexibility + Utility classes)
-   **Firebase** (Auth, Firestore, Storage)
-   **Framer Motion & AOS** (Animations)
-   **React Router v6** (Navigation)
