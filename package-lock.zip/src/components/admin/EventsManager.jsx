import React, { useState, useEffect } from 'react';
import { db } from '../../services/firebase';
import { collection, addDoc, deleteDoc, doc, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { motion, AnimatePresence } from 'framer-motion';
import { FaPlus, FaTrash, FaDatabase, FaCalendarAlt, FaMapMarkerAlt, FaBell, FaTools, FaFilter, FaSearch, FaTimes } from 'react-icons/fa';
import { dummyEvents } from '../../utils/dummyData';

const EventsManager = () => {
    const [events, setEvents] = useState([]);
    const [formData, setFormData] = useState({
        title: '',
        date: '',
        location: '',
        description: '',
        type: 'Exhibition' // Default type
    });
    
    // Filter State
    const [searchTerm, setSearchTerm] = useState('');
    const [filterDate, setFilterDate] = useState('');
    const [activeType, setActiveType] = useState('All');
    
    const [showModal, setShowModal] = useState(false);
    const [loading, setLoading] = useState(false);
    const [msg, setMsg] = useState('');

    const eventTypes = [
        'Exhibition', 
        'Product Launch', 
        'Technical Seminar', 
        'Corporate Gathering', 
        'Factory Visit'
    ];

    useEffect(() => {
        const unsubscribe = onSnapshot(collection(db, 'events'), snapshot => {
            const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }))
                .sort((a, b) => new Date(b.date) - new Date(a.date));
            setEvents(list);
        });
        return () => unsubscribe();
    }, []);

    const seedData = async () => {
        if(window.confirm('Sync demo event protocols?')) {
             setLoading(true);
             const promises = dummyEvents.map(e => addDoc(collection(db, 'events'), { ...e, createdAt: serverTimestamp(), type: 'Global Showcase' }));
             await Promise.all(promises);
             setLoading(false);
        }
    };

    const handleAddEvent = async (e) => {
        e.preventDefault();
        if(!formData.title || !formData.date) return;
        setLoading(true);
        try {
            await addDoc(collection(db, 'events'), {
                ...formData,
                createdAt: serverTimestamp()
            });
            setFormData({ title: '', date: '', location: '', description: '', type: 'Exhibition' });
            setShowModal(false);
            setMsg('Event Log Indexed');
            setTimeout(() => setMsg(''), 3000);
        } catch (err) {
            console.error(err);
        }
        setLoading(false);
    };

    const handleDelete = async (id) => {
        if(window.confirm('De-index this entire event entry?')) {
            await deleteDoc(doc(db, 'events', id));
        }
    };

    // Filtering Logic
    const filteredEvents = events.filter(ev => {
        const matchesSearch = !searchTerm || 
            ev.title?.toLowerCase().includes(searchTerm.toLowerCase()) || 
            ev.location?.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesDate = !filterDate || ev.date === filterDate;
        const matchesType = activeType === 'All' || ev.type === activeType;
        return matchesSearch && matchesDate && matchesType;
    });

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-4 px-2 gap-4">
                <div>
                    <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tighter">Strategic Chronology</h2>
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mt-1">Timeline management of corporate events and exhibitions.</p>
                </div>
                <div className="flex gap-2 w-full md:w-auto">
                    {msg && (
                        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="px-4 py-2 bg-slate-900 text-cyan-400 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg">
                            {msg}
                        </motion.div>
                    )}
                    <button 
                        onClick={() => setShowModal(true)}
                        className="flex-1 md:flex-initial px-6 py-2 bg-blue-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-blue-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 active:scale-95 border border-blue-500"
                    >
                        <FaPlus /> Initialize Event Node
                    </button>
                    <button onClick={seedData} className="px-4 py-2 bg-slate-100 text-slate-500 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-slate-200 transition-all flex items-center gap-2 border border-slate-200">
                        <FaDatabase className="text-slate-400" /> Demo Protocol Sync
                    </button>
                </div>
            </div>

            {/* Tactical Search & Filter Toolbar */}
            <div className="bg-white p-4 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col lg:flex-row gap-4 items-center justify-between mx-2">
                <div className="relative w-full lg:w-96 group">
                    <FaSearch className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-blue-500 transition-all text-xs" />
                    <input 
                        className="w-full bg-slate-50 border-2 border-slate-50 p-3.5 pl-14 rounded-2xl font-bold text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none transition-all" 
                        placeholder="Search event protocols..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>

                <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
                    <div className="relative flex-1 lg:flex-initial min-w-[160px] group">
                        <FaCalendarAlt className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-blue-500 transition-all text-xs" />
                        <input 
                            type="date"
                            className="w-full bg-slate-50 border-2 border-slate-50 p-3.5 pl-14 rounded-2xl font-black text-[10px] text-slate-900 focus:bg-white focus:border-blue-500 outline-none transition-all cursor-pointer uppercase" 
                            value={filterDate}
                            onChange={e => setFilterDate(e.target.value)}
                        />
                    </div>

                    <div className="relative flex-1 lg:flex-initial min-w-[160px] group">
                        <FaFilter className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-blue-500 transition-all text-xs" />
                        <select
                            value={activeType}
                            onChange={e => setActiveType(e.target.value)}
                            className="w-full bg-slate-50 border-2 border-slate-50 p-3.5 pl-14 pr-10 rounded-2xl font-black text-[10px] text-slate-900 uppercase tracking-widest focus:bg-white focus:border-blue-500 outline-none transition-all appearance-none cursor-pointer"
                        >
                            <option value="All">All Types</option>
                            {eventTypes.map(t => <option key={t} value={t}>{t}</option>)}
                        </select>
                        <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                        </div>
                    </div>
                </div>
            </div>

            {/* Events Timeline View */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 px-2 pb-20">
                {filteredEvents.map((ev, idx) => (
                    <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        key={ev.id} 
                        className="bg-white p-6 rounded-[2rem] border border-gray-100 flex gap-6 items-center relative group hover:border-blue-500/30 transition-all shadow-sm"
                    >
                        <div className="w-20 h-20 bg-slate-50 rounded-3xl border border-slate-100 flex flex-col items-center justify-center flex-shrink-0">
                            <span className="text-[10px] font-black text-blue-600 uppercase tracking-tighter">
                                {new Date(ev.date).toLocaleString('default', { month: 'short' })}
                            </span>
                            <span className="text-2xl font-black text-slate-900 leading-none">
                                {new Date(ev.date).getDate()}
                            </span>
                            <span className="text-[8px] font-black text-slate-400 uppercase">
                                {new Date(ev.date).getFullYear()}
                            </span>
                        </div>

                        <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                                <span className="text-[7px] font-black text-cyan-600 bg-cyan-50 px-2 py-0.5 rounded-full uppercase tracking-widest border border-cyan-100">
                                    {ev.type || 'Corporate'}
                                </span>
                            </div>
                            <h4 className="font-black text-slate-900 uppercase tracking-tighter text-base truncate pr-8">{ev.title}</h4>
                            <div className="flex items-center gap-4 mt-2">
                                <div className="flex items-center gap-1.5 text-slate-400">
                                    <FaMapMarkerAlt size={10} className="text-rose-500" />
                                    <span className="text-[10px] font-bold truncate max-w-[120px]">{ev.location}</span>
                                </div>
                                <div className="flex items-center gap-1.5 text-slate-400 border-l border-slate-100 pl-4">
                                    <FaBell size={10} className="text-blue-400" />
                                    <span className="text-[10px] font-bold">Scheduled</span>
                                </div>
                            </div>
                        </div>

                        <button 
                            onClick={() => handleDelete(ev.id)} 
                            className="absolute top-1/2 -translate-y-1/2 right-6 w-10 h-10 bg-rose-50 text-rose-400 rounded-xl flex items-center justify-center hover:bg-rose-500 hover:text-white transition-all shadow-sm"
                        >
                            <FaTrash size={14} />
                        </button>
                    </motion.div>
                ))}

                {filteredEvents.length === 0 && (
                    <div className="lg:col-span-2 p-20 bg-slate-50/50 rounded-[3rem] border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-center">
                        <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-slate-300 shadow-sm mb-4">
                            <FaCalendarAlt size={24} />
                        </div>
                        <h4 className="text-slate-400 font-black uppercase tracking-widest text-[10px]">No events match current parameters.</h4>
                        <p className="text-slate-300 text-[9px] font-bold uppercase tracking-widest mt-1 italic">Clear search or filters to resume monitoring.</p>
                    </div>
                )}
            </div>

            {/* Tactical Event Modal */}
            <AnimatePresence>
                {showModal && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4 overflow-hidden">
                        <motion.div 
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            onClick={() => setShowModal(false)}
                            className="absolute inset-0 bg-slate-950/90 backdrop-blur-xl"
                        ></motion.div>

                        <motion.div 
                            initial={{ scale: 0.95, opacity: 0, y: 20 }}
                            animate={{ scale: 1, opacity: 1, y: 0 }}
                            exit={{ scale: 0.95, opacity: 0, y: 20 }}
                            className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl relative overflow-hidden z-10"
                        >
                            <form onSubmit={handleAddEvent} className="p-12 space-y-8">
                                <div className="flex justify-between items-center mb-4">
                                    <div className="flex items-center gap-3 text-blue-600 font-black text-[10px] uppercase tracking-[0.4em]">
                                        <FaTools size={14} /> Global Event Initialization
                                    </div>
                                    <button 
                                        type="button"
                                        onClick={() => setShowModal(false)}
                                        className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all border border-slate-100"
                                    >
                                        <FaPlus className="rotate-45" />
                                    </button>
                                </div>
                                
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div className="space-y-6 md:col-span-2">
                                        <div className="space-y-2">
                                            <label className="text-[9px] font-black uppercase tracking-widest text-slate-400 ml-1">Event Designation (Title)</label>
                                            <input 
                                                className="w-full bg-slate-50 border-2 border-slate-50 p-5 rounded-2xl font-black text-lg text-slate-900 focus:bg-white focus:border-blue-500 outline-none transition-all" 
                                                placeholder="e.g. Glass Expo 2024"
                                                value={formData.title}
                                                onChange={e => setFormData({...formData, title: e.target.value})}
                                                required
                                                autoFocus
                                            />
                                        </div>
                                    </div>

                                    <div className="space-y-2">
                                        <label className="text-[9px] font-black uppercase tracking-widest text-slate-400 ml-1">Timeline Coordinate (Date)</label>
                                        <input 
                                            type="date"
                                            className="w-full bg-slate-50 border-2 border-slate-50 p-4 rounded-2xl font-bold text-sm text-slate-900 focus:bg-white focus:border-blue-500 outline-none transition-all" 
                                            value={formData.date}
                                            onChange={e => setFormData({...formData, date: e.target.value})}
                                            required
                                        />
                                    </div>

                                    <div className="space-y-2">
                                        <label className="text-[9px] font-black uppercase tracking-widest text-slate-400 ml-1">Event Classification</label>
                                        <select 
                                            className="w-full bg-slate-50 border-2 border-slate-50 p-4 rounded-2xl font-bold text-sm text-slate-900 focus:bg-white focus:border-blue-500 outline-none transition-all" 
                                            value={formData.type}
                                            onChange={e => setFormData({...formData, type: e.target.value})}
                                        >
                                            {eventTypes.map(t => <option key={t} value={t}>{t}</option>)}
                                        </select>
                                    </div>

                                    <div className="space-y-2 md:col-span-2">
                                        <label className="text-[9px] font-black uppercase tracking-widest text-slate-400 ml-1">Physical Location / Node</label>
                                        <div className="relative">
                                            <FaMapMarkerAlt className="absolute left-5 top-1/2 -translate-y-1/2 text-rose-500" size={14} />
                                            <input 
                                                className="w-full bg-slate-50 border-2 border-slate-50 p-5 pl-14 rounded-2xl font-bold text-sm text-slate-900 focus:bg-white focus:border-blue-500 outline-none transition-all" 
                                                placeholder="e.g. Dubai World Trade Centre"
                                                value={formData.location}
                                                onChange={e => setFormData({...formData, location: e.target.value})}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="pt-6 flex gap-4">
                                    <button 
                                        type="button" 
                                        onClick={() => setShowModal(false)}
                                        className="flex-1 bg-slate-100 text-slate-500 p-6 rounded-[2rem] font-black uppercase tracking-[0.2em] text-[10px] hover:bg-slate-200 transition-all active:scale-95"
                                    >
                                        Cancel Sync
                                    </button>
                                    <button 
                                        type="submit" 
                                        disabled={loading} 
                                        className="flex-[2] bg-slate-900 text-white p-6 rounded-[2rem] font-black uppercase tracking-[0.3em] text-[10px] flex items-center justify-center gap-4 hover:bg-black transition-all shadow-2xl shadow-slate-900/40 active:scale-95 disabled:opacity-50"
                                    >
                                        <FaPlus className="text-cyan-400" /> Commit Event Node
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default EventsManager;
